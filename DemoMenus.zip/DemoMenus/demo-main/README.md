# PELOS BECOS

# :video_game: ABOUT

Game demo for the SMAUG project of the Digital Games course at FATEC Carapicuíba. The game is a platformer where a brave cat faces urban challenges in search of its owner. 
The game explores themes of social inequality and adaptation to life in the city. Inspired by Jump King, it features challenging mechanics where precision is essential for success.

# :hammer: BUILD

Current Version 1.0.0 

<a href="https://games.gdevelop-app.com/game-a74780da-d0dc-4350-9fbe-ab3e204fed69/index.html" title="Play the game now" target="_blank">PLAY</a>

## QR CODE 

<div style="text-align:center">
<img src="./doc/imgs/qrcode_current_build_version.png">
</div>

# :rocket: LEVELS



# :octocat: DEVELOPED

Developed by **Double Catch Studio**